import pickle
import json
import pandas as pd                 # pandas is a dataframe library
import numpy as np
#from sklearn.externals import joblib
from sklearn.linear_model import Ridge
from azureml.core.model import Model
from azureml.monitoring import ModelDataCollector
import os
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier


from inference_schema.schema_decorators import input_schema, output_schema
from inference_schema.parameter_types.numpy_parameter_type import NumpyParameterType


def init():
    global model
    global scaler
    global le_dict
    
    print(os.getenv('AZUREML_MODEL_DIR'))
    # note here "regression_model.pkl" is the name of the model registered
    model_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'model_objects/trained_model_RF_US_35.pkl')
    scaler_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'model_objects/idws_scaler.pkl')
    encoder_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'model_objects/label_encoder_dictionary.pkl')
    print("printing Model Path")
    print(model_path)
    # deserialize the model file back into a sklearn model
    #model = joblib.load(model_path)
    
    with open(model_path,'rb') as handle:
        model = pickle.load(handle)
        
    with open(scaler_path,'rb') as handle:
        scaler = pickle.load(handle)

    with open(encoder_path,'rb') as handle:
        le_dict = pickle.load(handle)
    
    # configure data collection
    #global input_dc, prediction_dc
    #input_dc = ModelDataCollector(model_name = 'sk-model-test', designation="inputs", 
     #                             feature_names=["feat1", "feat2", "feat3", "feat4", "feat5", "feat6", "feat7", "feat8", "feat9", "feat10"])
   # prediction_dc = ModelDataCollector(model_name = 'sk-model-test', designation="predictions", feature_names=['prediction'])


# populate Swagger Endpoint
#input_sample = np.array([[ 0.01264814,  0.05068012,  0.00241654,  0.05630106,  0.02732605,
#        0.01716188,  0.04127682, -0.03949338,  0.00371174,  0.07348023]])
#output_sample = np.array([238.47])


def process_data_test(df_raw, null_dict, unknown_dict):
    df = df_raw.copy()
    
    # Load the encoder saved during training time.
    # le_dict = load_classifier_scaler('label_encoder_dictionary')
    #le_dict = load(open('label_encoder_dictionary.pkl', 'rb'))
    
    for col in df.columns:
        df[col] = df[col].fillna(null_dict[col])
    
    # Change unseen values to unknown classes    
    for col in df.columns:
        le_classes = set(le_dict[col].classes_)
        col_classes = set(df[col].value_counts().index)
        new_classes = list(col_classes.difference(le_classes))
        if new_classes:
            df[col] = df[col].replace(new_classes, unknown_dict[col])
    
    # Encode the data using existing label encoder.
    df = df.apply(lambda x: le_dict[x.name].transform(x.astype(str)))
    
    return df    

#Generate all the date columns in year, month, and Date cols. 
def GenerateDateCols(df, col):
    yr = col+'_Y'
    mo = col+'_M'
    days = col+'_D'
    df[yr] = pd.DatetimeIndex(df[col]).year
    df[mo] = pd.DatetimeIndex(df[col]).month
    df[days] = pd.DatetimeIndex(df[col]).day
    return df

#Take care of Overflow dates and set the pandas max date.
#Take care of Overflow dates and set the pandas max date.
def Fix_OverFlow_Dates(xDate):
    # Check if there is any error while converting to Date.
    x = pd.to_datetime(xDate, errors='coerce')
    if pd.isnull(x):
        date = pd.Timestamp.max
    else:
        date = x
    
    return(date)

def transform_for_pred(input_data):
    # Converting back from Json to Frame
    df_inp  = pd.read_json(path_or_buf=input_data, orient='records', typ='frame')
#     print ("input json -> df cols :", df_inp.columns)
    # Extracting PolNbr, EmpId column from Member rec
    df_inp['PolNbr'] = df_inp.MEMBER.str[2:9]
    df_inp['EmpId'] = df_inp.MEMBER.str[-15:-6]
    
    # Processing columns:
    date_list = ['FSTSRVDT',
                 'LSTSRVDT',
                 'FROM_YMD',
                 'PAIDDATE',
                 'RECV_YMD',
                 'MCVENDDT']
    numerical_list = ['Algorithmbatchrowid',
                     'claimgroup',
                     'AMT_CLAI',
                     'COINSAMT',
                     'AMT_DISA',
                     'AMT_DISC',
                     'AMT_PAID',
                     'COBSVAMT',
                     'COB_RDUC_AMT',
                     'RCNSD_RDUC_AMT',
                     'SPCL_NEGOT_DSCNT_AMT', 
                     'ADJ_NBR']
                     #'Status']

    categorical_list = ['coreextractid', 'DTL_NBR', 'CLAIMPOS',
                       'SRVCCNT', 'RVNU_CD', 'PROC_CD', 'DIAG1', 'DIAG2', 'DIAG3', 'DIAG_4_CD',
                       'DIAG_5_CD', 'PROC1', 'PROC2', 'PROC3', 'BIL_PROC_CD_CS', 'SRVRSNCD',
                       'OVRIDECD', 'CLM_LOC', 'PROVTIN', 'NTWKPARI', 'PROVNAME',
                       'PROV_SVC_ST', 'ADRTYPCD', 'PRBILST', 'PROV_CAT', 'PRODUCT',
                       'ISS_ST_ABBR_CD', 'MBRMKT', 'REL_CD', 'MKT_SEG', 'FINC_CD', 'CAPFLG',
                       'SHR_ARNG_CD', 'OBLIG_CD', 'CO_CD', 'COBIND', 'COB_MEDCR_PROC_TYP_CD',
                       'COB_CML_PROC_TYP_CD', 'DSCNT_TYP_CD', 'TRANS_CD', 'TRANS_CATGY_NM',
                       'FACL_CONTR_METH_CD', 'FM_TYP_CD', 'MNNRPPCT', 'SITUS_ST_ABBR_CD',
                       'MEDCR_PRI_IND', 'MNNRP_CD', 'INDV_ID', 'THREE_TIER_BEN_CD', 'BEN_LVL_SYS_ID',
                       'BEN_LVL_CAUS_CD', 'GDR_CD', 'MHSA_CD', 'SUBGRP_1_CD',
                       'SUBGRP_2_CD', 'CONTR_MKT_NBR', 'SBMT_VEND_CD', 'MEMBER', 'PolNbr', 'EmpId','REIM_POL_CD']
    
    # Marking all categorical columns as Object type
#     df_temp[categorical_list] = df_inp[categorical_list].astype('object') 
    df_temp = df_inp[categorical_list].astype('object') 
    print (df_temp.info(verbose=True))
    # Converting all numeric columns to numeric type
    for col in numerical_list:
        df_temp[col] = pd.to_numeric(df_inp[col])

    # Fix date time overflow error.
    for item in date_list:
        df_inp[item] = df_inp[item].apply(Fix_OverFlow_Dates)
    
    for col in date_list:
        df_temp[col] = pd.to_datetime(df_inp[col])
    
    # Converting only selected columns which were converted at the time of training. 
    for item in categorical_list:
        print(item)
        if (item != 'SRVCCNT' and item != 'MNNRPPCT' and item !='BEN_LVL_SYS_ID' and item !='INDV_ID'):
            df_temp[item].apply(str).str.upper()
            
    # Encoding Categorical data
    null_dict = {}
    unknown_dict = {}
    
    for key in categorical_list:
        null_dict[key] = "NULL_" + key
        unknown_dict[key] = "UNKNOWN_" + key
    
    df_categorical = df_temp[categorical_list].copy()
    df_categorical = process_data_test(df_categorical, null_dict, unknown_dict)
    df_temp[categorical_list] = df_categorical[categorical_list].copy()
    
    # Date Encoding part
    df_date = df_temp[date_list].copy()
    
    # Fill null values with max date.
    df_date.fillna(pd.Timestamp.max, inplace=True)
    
    # Convert the TimeDelta to days.
    df_date['diffPaidDtLstSrv'] =  round( (df_date.PAIDDATE - df_date.LSTSRVDT)/np.timedelta64(1,'D'))
    df_date['diffFstSrvCovEnd'] =  round( (df_date.MCVENDDT - df_date.FSTSRVDT)/np.timedelta64(1,'D'))
    
    # Generate new date columns and drop the original columns.
    for item in date_list:
        df_date = GenerateDateCols(df_date, item)

    df_date.drop(date_list, inplace=True, axis=1)  
    
    # Add new date columns and remove old ones
    date_cols_new = df_date.columns
    df_temp[date_cols_new] = df_date[date_cols_new].copy()
    df_temp.drop(date_list, inplace=True, axis=1)
    
    # Numerical Encoding & processing part
    df_numerical = df_temp[numerical_list].copy()
    
    # fill null values with 0 - As all are amount fields
    df_numerical.fillna(0, inplace=True)
    
    # Apply cube root transformation to numerical columns identified during training.
    right_skewed_col = ['claimgroup', 'AMT_CLAI', 'COINSAMT', 'AMT_DISA', 'AMT_DISC', 'AMT_PAID', 'COBSVAMT', 'COB_RDUC_AMT', 'SPCL_NEGOT_DSCNT_AMT']
    for col in right_skewed_col:
        df_numerical[col] = df_numerical[col].apply(lambda x:np.cbrt(x))
    
    # load the scaler
    #scaler = load(open('idws_scaler.pkl', 'rb'))
    df_preprocessing_scaled = scaler.transform(df_numerical)
    
    # Convert the ndarray id DataFrame.
    df_preprocessing_scaled_final = pd.DataFrame(data=df_preprocessing_scaled, index=df_temp.index, columns=df_numerical.columns)
    #Replace numerical data in actual dataframe.
    df_temp[df_numerical.columns] = df_preprocessing_scaled_final[df_numerical.columns].copy()
    
    df_out = df_temp.copy()
    print (df_out.head())
    return df_out

def ClaimRecoveryPrediction(transformed_df, threshold):
    Feature_col_names = ['coreextractid','CLAIMPOS','DIAG1','BIL_PROC_CD_CS','diffPaidDtLstSrv'
                            ,'ADJ_NBR','PROV_CAT','PROC_CD','DIAG2','PROVNAME','EmpId','PROVTIN'
                            ,'INDV_ID','OVRIDECD','PolNbr','diffFstSrvCovEnd','AMT_CLAI'
                            ,'CONTR_MKT_NBR','DIAG3','CLM_LOC','RVNU_CD','MBRMKT','RECV_YMD_D'
                            ,'PAIDDATE_D','SRVRSNCD','DIAG_4_CD','AMT_PAID','SUBGRP_1_CD','LSTSRVDT_D'
                            ,'FROM_YMD_D','FACL_CONTR_METH_CD','PRBILST','FSTSRVDT_D','AMT_DISC'
                            ,'SITUS_ST_ABBR_CD']
    
    test_pred = -1
    test_features = transformed_df[Feature_col_names].values    #Predicted Feature Columns.
    test_pred_proba = model.predict_proba(test_features)
    #Y_test = df2[Predicted_col_names].values  # Predicted Class (Target Value)
    for i in range(0,len(test_pred_proba)):
        if (test_pred_proba[i][1] > threshold):
            test_pred = 1
        else:
            test_pred = 0
    return test_pred


#@input_schema('data', NumpyParameterType(input_sample))
#@output_schema(NumpyParameterType(output_sample))
def run(data):
    try:
        data_dict = json.loads(data[1:-1])
        print("Processing request for CLM_AUD_NBR :", data_dict["CLM_AUD_NBR"])
        transformed_data = transform_for_pred(data)
        result = ClaimRecoveryPrediction(transformed_data, 0.47)
        #transformed_data = transform_for_pred(input_data)
        #result = model.predict(transformed_data)
        # you can return any datatype as long as it is JSON-serializable
        #input_dc.collect(data)
        #prediction_dc.collect(result)
        return json.dumps(result)
    except Exception as e:
        error = str(e)
        return error
    
