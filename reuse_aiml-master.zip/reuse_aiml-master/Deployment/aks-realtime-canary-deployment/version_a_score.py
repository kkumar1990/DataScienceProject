import json
import numpy as np
import os
import xgboost as xgb

from azureml.core.model import Model
from azureml.monitoring import ModelDataCollector

from inference_schema.schema_decorators import input_schema, output_schema
from inference_schema.parameter_types.numpy_parameter_type import NumpyParameterType

### Initialize globals for repeated use in the 'run' function ###
def init():
    global model

    ### Note here "xgb_higgs_gpu.pkl" is the name of the model object registered ###
    model_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'xgb_higgs_gpu.pkl')
    
    ### Deserialize the model file back into an XGBoost model ###
    model = xgb.Booster({'nthread': 4})
    model.load_model(model_path)

    ### Configure data collection for retroactive analysis of incoming request data ###
    global input_dc, prediction_dc

    input_dc = ModelDataCollector(model_name = 'higgs-xgboost-version-a', 
                                  model_version = '1',
                                  webservice_name = 'higgsxgboost',
                                  designation = 'inputs', 
                                  feature_names = ['feat1', 'feat2', 'feat3', 'feat4', 'feat5', 'feat6', 'feat7', 'feat8', 'feat9', 'feat10',
                                                'feat11', 'feat12', 'feat13', 'feat14', 'feat15', 'feat16', 'feat17', 'feat18', 'feat19', 'feat20',
                                                'feat21', 'feat22', 'feat23', 'feat24', 'feat25', 'feat26', 'feat27', 'feat28'])

    prediction_dc = ModelDataCollector(model_name = 'higgs-xgboost-version-a',
                                       model_version = '1',
                                       webservice_name = 'higgsxgboost',
                                       designation = 'predictions', 
                                       feature_names = ['prediction'])

### Provide example inputs and outputs to populate Swagger Endpoint ###
input_sample = np.array([[1.1386826, -0.72663486, -0.00578982, 0.20411839, 0.15384236, 1.58590412,
                        -0.04557601, -1.44852722, 1.08653808, 1.59847081, 0.39929485, 0.12806517,
                        2.21487212, 1.20669425, 0.1385307, 1.29632187, 0.000000, 0.37922832,
                        -2.43980002, 0.07364186, 0.000000, 1.79049718, 1.73059154, 0.98058659,
                        0.74306524, 2.37875152, 1.53486252, 1.22755849]])
output_sample = np.array([-0.8446956])

### Provide logic to be run on each request to the service ###
@input_schema('data', NumpyParameterType(input_sample))
@output_schema(NumpyParameterType(output_sample))
def run(data):
    try:
        dmatrix_input = xgb.DMatrix(data)
        result = model.predict(dmatrix_input)
        
        ### Collect inputs and predictions for future analysis ###
        input_dc.collect(data)
        prediction_dc.collect(result)

        ### you can return any datatype as long as it is JSON-serializable ###
        return result.tolist()
    except Exception as e:
        error = str(e)
        return error