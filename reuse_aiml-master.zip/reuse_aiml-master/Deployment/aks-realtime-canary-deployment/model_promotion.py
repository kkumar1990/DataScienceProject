from azureml.core import Workspace
from azureml.core.webservice import AksEndpoint

### Authenticate to AzureML Workspace ###
workspace_name = 'mlblog2'

resource_group = '{}-common'.format(workspace_name)
workspace_name = '{}-aml'.format(workspace_name)

subscription_id = 'b9a8036a-370e-4737-a287-7082737c2534'

ws = Workspace.get(name = workspace_name,
                   subscription_id = subscription_id,
                   resource_group = resource_group)

### Get reference to AKSEndpoint ###
endpoint_name = 'higgs-xgboost'
endpoint = AksEndpoint(ws, endpoint_name)

### Update version A to lower traffic percentile ###
print('... Updating Model Version A with decreased traffic percentile ...')
version_a_name = 'higgs-version-a'
endpoint.update_version(version_name=endpoint.versions[version_a_name].name,
                        traffic_percentile=20)

### Wait for the update to complete before udpating version B ###
endpoint.wait_for_deployment(True)

### Update version B to higher traffic percentile and designate as default + control ###
print('... Updating Model Version B with increased traffic percentile ...')
version_b_name = 'higgs-version-b'
endpoint.update_version(version_name=endpoint.versions[version_b_name].name,
                        traffic_percentile=80,
                        is_default=True,
                        is_control_version_type=True)

### Wait for the update to complete before deleting ###
endpoint.wait_for_deployment(True)

### Delete version A in the endpoint ###
print('... Deleting outdated Model version ...')
version_a_name = 'higgs-version-a'
endpoint.delete_version(version_name=version_a_name)