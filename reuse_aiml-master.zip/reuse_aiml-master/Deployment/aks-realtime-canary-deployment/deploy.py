from azureml.core import Experiment, Workspace
from azureml.core.compute import AksCompute, ComputeTarget
from azureml.core.model import InferenceConfig, Model
from azureml.core.webservice import AksEndpoint, AksWebservice, Webservice

### Authenticate to AzureML Workspace ###
workspace_name = 'mlblog2'

resource_group = '{}-common'.format(workspace_name)
workspace_name = '{}-aml'.format(workspace_name)

subscription_id = 'b9a8036a-370e-4737-a287-7082737c2534'

ws = Workspace.get(name = workspace_name,
                   subscription_id = subscription_id,
                   resource_group = resource_group)

### Load AzureML Models ###
model_name = 'demo-higgs'

model_a_version = 1
model_a = Model(ws, name = model_name, version = model_a_version)

model_b_version = 2
model_b = Model(ws, name = model_name, version = model_b_version)

### Create inference configs for model scoring ###
path_to_files = "."

inference_config_a = InferenceConfig(entry_script="{}/version_a_score.py".format(path_to_files),
                                     conda_file="{}/env.yml".format(path_to_files),
                                     runtime="python")

inference_config_b = InferenceConfig(entry_script="{}/version_b_score.py".format(path_to_files),
                                     conda_file="{}/env.yml".format(path_to_files),
                                     runtime="python")

### Reference the deployment compute target ###
aks_name = 'mlblogaks2'
aks_target = ComputeTarget(ws, aks_name)
namespace = 'models'

### Define the endpoint and version name ###
endpoint_name = 'higgs-xgboost'
version_a_name = 'higgs-version-a'
version_a_traffic = 80

### Create the deployment config and define the scoring traffic percentile for the first deployment ###
endpoint_deployment_config = AksEndpoint.deploy_configuration(cpu_cores = 1, 
                                                              memory_gb = 1,
                                                              enable_app_insights = True,
                                                              collect_model_data = True,
                                                              tags = {'modelName': model_name, 'modelType': 'XGBoost', 'modelVersion': '1'},
                                                              description = 'XGBoost model trained on UCI Higgs dataset',
                                                              version_name = version_a_name,
                                                              traffic_percentile = version_a_traffic,
                                                              auth_enabled = True,
                                                              namespace = namespace)

### Deploy the model and endpoint ###
print(f'... Deploying Model Version A (Control): {version_a_traffic}% traffic ...')
endpoint = Model.deploy(ws, endpoint_name, [model_a], inference_config_a, endpoint_deployment_config, aks_target)
endpoint.wait_for_deployment(True)

### Add second model with different traffic percentile ###
version_b_name = 'higgs-version-b'
version_b_traffic = 20

print(f'... Deploying Model Version B (Treatment): {version_b_traffic}% traffic ...')
endpoint.create_version(cpu_cores = .5, 
                        memory_gb = .5,
                        models = [model_b],
                        inference_config = inference_config_b,
                        collect_model_data = True,
                        tags = {'modelName': model_name, 'modelType': 'XGBoost', 'modelVersion': '2'},
                        description = 'XGBoost model trained on UCI Higgs dataset',
                        version_name = version_b_name,
                        traffic_percentile = 20)
endpoint.wait_for_deployment(True)