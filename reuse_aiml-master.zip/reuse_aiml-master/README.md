# AIML Evangelisation 
This repository provides AIML starter kit for developers and resources for leadership.
 
### Prerequisites
- Python 3
- Anaconda(Jupyter Notebook)

Both can be installed via Appstore. http://appstore.uhc.com/

## Contributing
Please refer to [Contribution Guidelines](docs/CONTRIBUTING.md) and [Code of Conduct](docs/CODE_OF_CONDUCT.md) for guidance on contributing to this project. 

### Maintainers
[AIML Evangelisation Team](https://github.optum.com/agupt38/reuse_aiml/graphs/contributors)
