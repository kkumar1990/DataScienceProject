# AI For ALL Foundations: 

## Python Series basics :
https://github.optum.com/paymentintegrity/Python_Series_for_AI_ML

## ML-Boot :
https://github.optum.com/paymentintegrity/ML-BOOT

## Reusable AI/ML :
https://github.optum.com/agupt38/reuse_aiml
