## ML - BOOT
[![Flowdock](https://img.shields.io/badge/chat-on%20Flowdock-brightgreen.svg)](https://www.flowdock.com/app/uhg/documentation)

</div>

## 🧐 About <a name = "about"></a>
- ML - BOOT platform will help the organization for building Machine Learning models for various problems in the systems. Most of the time, engineers find the Machine Learning problems but they get stuck at the time of data pre-processing, data cleaning and     finally feature building which is the building block of Machine Learning models. ML-Boot platform has been built to solve such problems.

## Why Feature Enginnering
Every machine learning algorithms need input data to build outputs. This input data comprise features, which are usually in the form of structured columns.

Any attribute could be a feature, as long as it is useful to the model.

## Feature engineering efforts primarily have two goals:

- Preparing the proper input data set, compatible with the machine learning algorithm requirements.
- Improving the performance of machine learning models.

## It covers primarily three areas :
 - Exploratory data analysis (MLBOOT - Graphs & Analysis)
 - Feature Engineering (MLBOOT- Feature Engineering)
 - Model Building and evaluation (MLBOOT - Model Building And Evaluation)
 
## Follow the below steps which will result in giving the best Model :
 - Pass the Raw data to EDA Notebook which will give graphical representation of all independent variables explaining the Target Variables.
 
 - Pass the Raw data to Feature Enginnering framework will generate the transformed/cleaned data which can be used for Model building.
 
 - Import the transformed data resulted from Feature Engineering and run for different Algorithms which will give the best performing     
   Model, Save the Model that can be deployed as Rest API for application integration. 
   
# Project Rules

- [Code of Conduct](https://github.optum.com/paymentintegrity/ML-BOOT/blob/master/CODE_OF_CONDUCT.md)

## 🤝 Contributing

Contributions are always welcome, no matter how large or small. Before contributing, please read the [code of conduct]. We are always looking for [support].

Please refer to out [Contribution Guidelines](https://github.optum.com/paymentintegrity/ML-BOOT/blob/master/CONTRIBUTING.md) for guidance on contributing to this project. There is also a [pull request template](hhttps://github.optum.com/paymentintegrity/ML-BOOT/blob/master/pull_request_template.md) in this repository for guiding contributors through the pull request process.

## ✍️ Authors

- Gupta, Alok alok.gupta38@optum.com

## References

### Whitepaper link : https://new-wiki.optum.com/x/OUgLBQ
 
### Model Deployment references:

Jenkins Path : https://jenkins.optum.com/cobwow/job/cobprimacy_dev/

GitHub Path : https://github.optum.com/COB/COBPrimacy.git

### References for Feature Selection Algorithms:

https://www.analyticsvidhya.com/blog/2016/12/introduction-to-feature-selection-methods-with-an-example-or-how-to-select-the-right-variables/

 
https://elitedatascience.com/dimensionality-reduction-algorithms
 
 
http://www.ai.mit.edu/projects/jmlr/papers/volume3/guyon03a/source/old/guyon03a.pdf


### Data Reference for testing:

https://github.optum.com/agupt38/cobwow-mlprimacypredictiveanalysis/blob/data/trainingData.csv


